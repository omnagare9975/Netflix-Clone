This directory contains license files and notices from binaries built for this
image and the dependencies of those binaries,
as collected by https://github.com/google/go-licenses.
